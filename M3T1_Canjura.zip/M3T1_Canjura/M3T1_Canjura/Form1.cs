﻿/**
* 02/21/2018
* CSC 153
* Gabriela Canjura
* calculates gross pay with or without overtime
*/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace M3T1_Canjura
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void calculateButton_Click(object sender, EventArgs e)
        {
           try
            {
                // constants
                const decimal BASE_HOURS = 40m;
                const decimal OT_MULTIPLIER = 1.5m;

                //local Variables
                decimal hoursWorked;
                decimal hourlyPayRate;
                decimal basePay;
                decimal overtimeHours;
                decimal overtimePay;
                decimal grossPay;

                //get input from user and assign to variables
                hoursWorked = decimal.Parse(hoursWorkedTextBox.Text);
                hourlyPayRate = decimal.Parse(hourlyPayRateTextBox.Text);

                if (hoursWorked>BASE_HOURS)
                {
                    //base pay calculations
                    basePay = hourlyPayRate * BASE_HOURS;

                    // gets number of overtime hours
                    overtimeHours = hoursWorked - BASE_HOURS;

                    //gets pay for ovetime hours
                    overtimePay = overtimeHours * hourlyPayRate * OT_MULTIPLIER;

                    //adds base and over time pay
                    grossPay = basePay + overtimePay;
                }
                else
                {
                    //gets gross pay without OT
                    grossPay = hoursWorked * hourlyPayRate;
                }

                grossPayLabel.Text = grossPay.ToString("c");
            }
            
            catch (Exception ex)
            {
                //displays error mesage
                MessageBox.Show("Input type is invalid format.");
            }
        }

        private void clearButton_Click(object sender, EventArgs e)
        {
            // clears text boxes and label
            hoursWorkedTextBox.Text = "";
            hourlyPayRateTextBox.Text = "";
            grossPayLabel.Text = "";
            
            //resets the focus
            hoursWorkedTextBox.Focus();
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            //closes form
            this.Close();
        }
    }
}
