﻿namespace M3HW2_Canjura
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.packagesTextBox = new System.Windows.Forms.TextBox();
            this.directionslabel = new System.Windows.Forms.Label();
            this.retailPriceLabel = new System.Windows.Forms.Label();
            this.discountLabel = new System.Windows.Forms.Label();
            this.costLabel = new System.Windows.Forms.Label();
            this.retailDisplayLabel = new System.Windows.Forms.Label();
            this.discountDisplayLabel = new System.Windows.Forms.Label();
            this.packagesLabel = new System.Windows.Forms.Label();
            this.costDisplayLabel = new System.Windows.Forms.Label();
            this.calculateButton = new System.Windows.Forms.Button();
            this.clearButton = new System.Windows.Forms.Button();
            this.exitButton = new System.Windows.Forms.Button();
            this.percentLabel = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // packagesTextBox
            // 
            this.packagesTextBox.Location = new System.Drawing.Point(183, 43);
            this.packagesTextBox.Name = "packagesTextBox";
            this.packagesTextBox.Size = new System.Drawing.Size(100, 20);
            this.packagesTextBox.TabIndex = 0;
            // 
            // directionslabel
            // 
            this.directionslabel.AutoSize = true;
            this.directionslabel.Location = new System.Drawing.Point(33, 18);
            this.directionslabel.Name = "directionslabel";
            this.directionslabel.Size = new System.Drawing.Size(340, 13);
            this.directionslabel.TabIndex = 1;
            this.directionslabel.Text = "Enter the number of packages you would like to buy to obtain the cost.";
            // 
            // retailPriceLabel
            // 
            this.retailPriceLabel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.retailPriceLabel.Location = new System.Drawing.Point(183, 78);
            this.retailPriceLabel.Name = "retailPriceLabel";
            this.retailPriceLabel.Size = new System.Drawing.Size(100, 23);
            this.retailPriceLabel.TabIndex = 2;
            this.retailPriceLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // discountLabel
            // 
            this.discountLabel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.discountLabel.Location = new System.Drawing.Point(183, 119);
            this.discountLabel.Name = "discountLabel";
            this.discountLabel.Size = new System.Drawing.Size(100, 23);
            this.discountLabel.TabIndex = 3;
            this.discountLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // costLabel
            // 
            this.costLabel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.costLabel.Location = new System.Drawing.Point(183, 162);
            this.costLabel.Name = "costLabel";
            this.costLabel.Size = new System.Drawing.Size(100, 23);
            this.costLabel.TabIndex = 4;
            this.costLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // retailDisplayLabel
            // 
            this.retailDisplayLabel.AutoSize = true;
            this.retailDisplayLabel.Location = new System.Drawing.Point(106, 83);
            this.retailDisplayLabel.Name = "retailDisplayLabel";
            this.retailDisplayLabel.Size = new System.Drawing.Size(61, 13);
            this.retailDisplayLabel.TabIndex = 5;
            this.retailDisplayLabel.Text = "Retail Cost:";
            // 
            // discountDisplayLabel
            // 
            this.discountDisplayLabel.AutoSize = true;
            this.discountDisplayLabel.Location = new System.Drawing.Point(115, 124);
            this.discountDisplayLabel.Name = "discountDisplayLabel";
            this.discountDisplayLabel.Size = new System.Drawing.Size(52, 13);
            this.discountDisplayLabel.TabIndex = 6;
            this.discountDisplayLabel.Text = "Discount:";
            // 
            // packagesLabel
            // 
            this.packagesLabel.AutoSize = true;
            this.packagesLabel.Location = new System.Drawing.Point(109, 46);
            this.packagesLabel.Name = "packagesLabel";
            this.packagesLabel.Size = new System.Drawing.Size(58, 13);
            this.packagesLabel.TabIndex = 7;
            this.packagesLabel.Text = "Packages:";
            // 
            // costDisplayLabel
            // 
            this.costDisplayLabel.AutoSize = true;
            this.costDisplayLabel.Location = new System.Drawing.Point(136, 167);
            this.costDisplayLabel.Name = "costDisplayLabel";
            this.costDisplayLabel.Size = new System.Drawing.Size(31, 13);
            this.costDisplayLabel.TabIndex = 8;
            this.costDisplayLabel.Text = "Cost:";
            // 
            // calculateButton
            // 
            this.calculateButton.Location = new System.Drawing.Point(68, 218);
            this.calculateButton.Name = "calculateButton";
            this.calculateButton.Size = new System.Drawing.Size(75, 23);
            this.calculateButton.TabIndex = 9;
            this.calculateButton.Text = "Calculate ";
            this.calculateButton.UseVisualStyleBackColor = true;
            this.calculateButton.Click += new System.EventHandler(this.calculateButton_Click);
            // 
            // clearButton
            // 
            this.clearButton.Location = new System.Drawing.Point(173, 218);
            this.clearButton.Name = "clearButton";
            this.clearButton.Size = new System.Drawing.Size(75, 23);
            this.clearButton.TabIndex = 10;
            this.clearButton.Text = "Clear";
            this.clearButton.UseVisualStyleBackColor = true;
            this.clearButton.Click += new System.EventHandler(this.clearButton_Click);
            // 
            // exitButton
            // 
            this.exitButton.Location = new System.Drawing.Point(280, 218);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(75, 23);
            this.exitButton.TabIndex = 11;
            this.exitButton.Text = "Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // percentLabel
            // 
            this.percentLabel.Location = new System.Drawing.Point(289, 119);
            this.percentLabel.Name = "percentLabel";
            this.percentLabel.Size = new System.Drawing.Size(40, 23);
            this.percentLabel.TabIndex = 12;
            this.percentLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(429, 262);
            this.Controls.Add(this.percentLabel);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.clearButton);
            this.Controls.Add(this.calculateButton);
            this.Controls.Add(this.costDisplayLabel);
            this.Controls.Add(this.packagesLabel);
            this.Controls.Add(this.discountDisplayLabel);
            this.Controls.Add(this.retailDisplayLabel);
            this.Controls.Add(this.costLabel);
            this.Controls.Add(this.discountLabel);
            this.Controls.Add(this.retailPriceLabel);
            this.Controls.Add(this.directionslabel);
            this.Controls.Add(this.packagesTextBox);
            this.Name = "Form1";
            this.Text = "Software Sales";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox packagesTextBox;
        private System.Windows.Forms.Label directionslabel;
        private System.Windows.Forms.Label retailPriceLabel;
        private System.Windows.Forms.Label discountLabel;
        private System.Windows.Forms.Label costLabel;
        private System.Windows.Forms.Label retailDisplayLabel;
        private System.Windows.Forms.Label discountDisplayLabel;
        private System.Windows.Forms.Label packagesLabel;
        private System.Windows.Forms.Label costDisplayLabel;
        private System.Windows.Forms.Button calculateButton;
        private System.Windows.Forms.Button clearButton;
        private System.Windows.Forms.Button exitButton;
        private System.Windows.Forms.Label percentLabel;
    }
}

