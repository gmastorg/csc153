﻿/**
* 02/28/2018
* CSC 153
* Gabriela Canjura
* calculates cost and discount for certain amounts of packages of softwares ordered
*/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace M3HW2_Canjura
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void clearButton_Click(object sender, EventArgs e)
        {
            retailPriceLabel.Text = "";
            costLabel.Text = "";
            discountLabel.Text = "";
            packagesTextBox.Text = "";
            percentLabel.Text = "";
        }

        private void calculateButton_Click(object sender, EventArgs e)
        {
            int packages;
            decimal price = 99m; // makes price per package of $99
            decimal discount;
            decimal retail;
            decimal cost;

            if (int.TryParse(packagesTextBox.Text, out packages)) // validates input data
            {
                if (packages <= 9)
                {
                    retail = packages * price; // price without discount
                    discount = 0;
                    cost = retail; // no discount applied thus retail and cost are same
                    costLabel.Text = cost.ToString("c");
                    retailPriceLabel.Text = retail.ToString("C");
                    discountLabel.Text = discount.ToString("c");
                    percentLabel.Text = "0%";
                }
                /*
                 * for all below 
                 * retail = price without discount
                 * discount = monetary amount saved
                 * cost = gives the amount customer would pay
                 * percentageLabel.Text = displays the discount received in percent
                 */

                else if (10 <= packages && packages <= 19)
                {
                    retail = packages * price;  
                    discount = retail * .20m; 
                    cost = retail * .80m;
                    costLabel.Text = cost.ToString("c");
                    retailPriceLabel.Text = retail.ToString("C");
                    discountLabel.Text = discount.ToString("c");
                    percentLabel.Text = "20%"; 
                }


                else if (20 <= packages && packages <= 49)
                {
                    retail = packages * price;
                    discount = retail * .30m;
                    cost = retail * .70m;
                    costLabel.Text = cost.ToString("c");
                    retailPriceLabel.Text = retail.ToString("C");
                    discountLabel.Text = discount.ToString("c");
                    percentLabel.Text = "30%";
                }

                else if (50 <= packages && packages <= 99)
                {
                    retail = packages * price;
                    discount = retail * .40m;
                    cost = retail * .60m;
                    costLabel.Text = cost.ToString("c");
                    retailPriceLabel.Text = retail.ToString("C");
                    discountLabel.Text = discount.ToString("c");
                    percentLabel.Text = "40%";
                }

                else if (100 <= packages)
                {
                    retail = packages * price;
                    discount = retail * .50m;
                    cost = retail * .50m;
                    costLabel.Text = cost.ToString("c");
                    retailPriceLabel.Text = retail.ToString("C");
                    discountLabel.Text = discount.ToString("c");
                    percentLabel.Text = "50%";
                }
            }
            else // displays error message is input not valid
            {
                MessageBox.Show("Enter a valid number.");
            }
        }
    }
}

