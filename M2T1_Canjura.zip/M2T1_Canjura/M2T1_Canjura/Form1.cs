﻿/**
* 02/07/18
* CSC 153
* Gabriela Canjura
* calculates miles per gallon
*/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace M2T1_Canjura
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void calculateButton_Click(object sender, EventArgs e)
        {
            double miles;
            double gallons;
            double mpg;

            miles = double.Parse(milesTextBox.Text);
            gallons = double.Parse(gallonsTextBox.Text);

            mpg = miles / gallons;

            mpgLabel.Text = mpg.ToString();

        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
