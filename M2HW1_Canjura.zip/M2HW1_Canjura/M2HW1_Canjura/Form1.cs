﻿/**
* 02/12/2018
* CSC 153
* Gabriela Canjura
* Formats a name entered 6 different ways, clears and exits 
*/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace M2HW1_Canjura
{
    public partial class Form1 : Form
    {
        private string t = ""; //t= title
        string f = ""; //f = first
        string m = ""; //m = middle
        string l = ""; //l = last

        public Form1()
        {
            InitializeComponent();
        }

        private void get_data() // method to collect data
        { 
                t = titleTextBox.Text + " ";
                f = firstnameTextBox.Text + " ";
                m = middleNameTextBox.Text + " ";
                l = lastNameTextBox.Text + " ";            
        }

        private void titleFirstMidLastButton_Click(object sender, EventArgs e)
        {
            get_data();
            outputLabel.Text = (t + f + m + l);
            // diplays title first middle last that is input by user
        }

        private void FirstMidLastButton_Click(object sender, EventArgs e)
        {
            get_data();
            outputLabel.Text = (f + m + l);
            // diplays first middle last that is input by user
        }

        private void firstLastButton_Click(object sender, EventArgs e)
        {
            get_data();
            outputLabel.Text = (f + l);
            // diplays first last that is input by user
        }

        private void lastFirstMidTitleButton_Click(object sender, EventArgs e)
        {
            get_data();
            outputLabel.Text = (l + "," + f + m + "," + t);
            // diplays title first middle last that is input by user
        }

        private void lastFirstMidButton_Click(object sender, EventArgs e)
        {
            get_data();
            outputLabel.Text = (l + "," + f + m);
            //displays last, first middle
        }

        private void lastFirstButton_Click(object sender, EventArgs e)
        {
            get_data();
            outputLabel.Text = (l + "," + f);
            //displays last, first
        }

        private void clearButton_Click(object sender, EventArgs e)
        {
            titleTextBox.Text = "";
            firstnameTextBox.Text = "";
            middleNameTextBox.Text = "";
            lastNameTextBox.Text = "";
            outputLabel.Text = "";
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
