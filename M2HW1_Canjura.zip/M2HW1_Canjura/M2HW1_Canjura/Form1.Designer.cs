﻿namespace M2HW1_Canjura
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.FirstNamePromptLabel = new System.Windows.Forms.Label();
            this.lastNamePromptLabel = new System.Windows.Forms.Label();
            this.middleNamePromptLabel = new System.Windows.Forms.Label();
            this.titleLabel = new System.Windows.Forms.Label();
            this.firstnameTextBox = new System.Windows.Forms.TextBox();
            this.middleNameTextBox = new System.Windows.Forms.TextBox();
            this.titleTextBox = new System.Windows.Forms.TextBox();
            this.lastNameTextBox = new System.Windows.Forms.TextBox();
            this.titleFirstMidLastButton = new System.Windows.Forms.Button();
            this.FirstMidLastButton = new System.Windows.Forms.Button();
            this.firstLastButton = new System.Windows.Forms.Button();
            this.lastFirstMidTitleButton = new System.Windows.Forms.Button();
            this.lastFirstMidButton = new System.Windows.Forms.Button();
            this.lastFirstButton = new System.Windows.Forms.Button();
            this.clearButton = new System.Windows.Forms.Button();
            this.exitButton = new System.Windows.Forms.Button();
            this.outputLabel = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // FirstNamePromptLabel
            // 
            this.FirstNamePromptLabel.AutoSize = true;
            this.FirstNamePromptLabel.BackColor = System.Drawing.SystemColors.Control;
            this.FirstNamePromptLabel.Location = new System.Drawing.Point(23, 45);
            this.FirstNamePromptLabel.Name = "FirstNamePromptLabel";
            this.FirstNamePromptLabel.Size = new System.Drawing.Size(60, 13);
            this.FirstNamePromptLabel.TabIndex = 0;
            this.FirstNamePromptLabel.Text = "First Name:";
            // 
            // lastNamePromptLabel
            // 
            this.lastNamePromptLabel.AutoSize = true;
            this.lastNamePromptLabel.Location = new System.Drawing.Point(22, 97);
            this.lastNamePromptLabel.Name = "lastNamePromptLabel";
            this.lastNamePromptLabel.Size = new System.Drawing.Size(61, 13);
            this.lastNamePromptLabel.TabIndex = 1;
            this.lastNamePromptLabel.Text = "Last Name:";
            // 
            // middleNamePromptLabel
            // 
            this.middleNamePromptLabel.AutoSize = true;
            this.middleNamePromptLabel.Location = new System.Drawing.Point(12, 71);
            this.middleNamePromptLabel.Name = "middleNamePromptLabel";
            this.middleNamePromptLabel.Size = new System.Drawing.Size(72, 13);
            this.middleNamePromptLabel.TabIndex = 2;
            this.middleNamePromptLabel.Text = "Middle Name:";
            // 
            // titleLabel
            // 
            this.titleLabel.AutoSize = true;
            this.titleLabel.Location = new System.Drawing.Point(53, 15);
            this.titleLabel.Name = "titleLabel";
            this.titleLabel.Size = new System.Drawing.Size(30, 13);
            this.titleLabel.TabIndex = 3;
            this.titleLabel.Text = "Title:";
            // 
            // firstnameTextBox
            // 
            this.firstnameTextBox.Location = new System.Drawing.Point(103, 42);
            this.firstnameTextBox.Name = "firstnameTextBox";
            this.firstnameTextBox.Size = new System.Drawing.Size(139, 20);
            this.firstnameTextBox.TabIndex = 2;
            // 
            // middleNameTextBox
            // 
            this.middleNameTextBox.Location = new System.Drawing.Point(103, 71);
            this.middleNameTextBox.Name = "middleNameTextBox";
            this.middleNameTextBox.Size = new System.Drawing.Size(139, 20);
            this.middleNameTextBox.TabIndex = 3;
            // 
            // titleTextBox
            // 
            this.titleTextBox.Location = new System.Drawing.Point(103, 16);
            this.titleTextBox.Name = "titleTextBox";
            this.titleTextBox.Size = new System.Drawing.Size(139, 20);
            this.titleTextBox.TabIndex = 1;
            // 
            // lastNameTextBox
            // 
            this.lastNameTextBox.Location = new System.Drawing.Point(103, 97);
            this.lastNameTextBox.Name = "lastNameTextBox";
            this.lastNameTextBox.Size = new System.Drawing.Size(139, 20);
            this.lastNameTextBox.TabIndex = 4;
            // 
            // titleFirstMidLastButton
            // 
            this.titleFirstMidLastButton.Location = new System.Drawing.Point(15, 187);
            this.titleFirstMidLastButton.Name = "titleFirstMidLastButton";
            this.titleFirstMidLastButton.Size = new System.Drawing.Size(123, 23);
            this.titleFirstMidLastButton.TabIndex = 5;
            this.titleFirstMidLastButton.Text = "Title First Middle Last";
            this.titleFirstMidLastButton.UseVisualStyleBackColor = true;
            this.titleFirstMidLastButton.Click += new System.EventHandler(this.titleFirstMidLastButton_Click);
            // 
            // FirstMidLastButton
            // 
            this.FirstMidLastButton.Location = new System.Drawing.Point(15, 229);
            this.FirstMidLastButton.Name = "FirstMidLastButton";
            this.FirstMidLastButton.Size = new System.Drawing.Size(123, 23);
            this.FirstMidLastButton.TabIndex = 6;
            this.FirstMidLastButton.Text = "First Middle Last";
            this.FirstMidLastButton.UseVisualStyleBackColor = true;
            this.FirstMidLastButton.Click += new System.EventHandler(this.FirstMidLastButton_Click);
            // 
            // firstLastButton
            // 
            this.firstLastButton.Location = new System.Drawing.Point(15, 269);
            this.firstLastButton.Name = "firstLastButton";
            this.firstLastButton.Size = new System.Drawing.Size(123, 23);
            this.firstLastButton.TabIndex = 7;
            this.firstLastButton.Text = "First Last";
            this.firstLastButton.UseVisualStyleBackColor = true;
            this.firstLastButton.Click += new System.EventHandler(this.firstLastButton_Click);
            // 
            // lastFirstMidTitleButton
            // 
            this.lastFirstMidTitleButton.Location = new System.Drawing.Point(162, 187);
            this.lastFirstMidTitleButton.Name = "lastFirstMidTitleButton";
            this.lastFirstMidTitleButton.Size = new System.Drawing.Size(128, 23);
            this.lastFirstMidTitleButton.TabIndex = 8;
            this.lastFirstMidTitleButton.Text = "Last, First Middle, Title";
            this.lastFirstMidTitleButton.UseVisualStyleBackColor = true;
            this.lastFirstMidTitleButton.Click += new System.EventHandler(this.lastFirstMidTitleButton_Click);
            // 
            // lastFirstMidButton
            // 
            this.lastFirstMidButton.Location = new System.Drawing.Point(162, 229);
            this.lastFirstMidButton.Name = "lastFirstMidButton";
            this.lastFirstMidButton.Size = new System.Drawing.Size(128, 23);
            this.lastFirstMidButton.TabIndex = 9;
            this.lastFirstMidButton.Text = "Last, First Middle";
            this.lastFirstMidButton.UseVisualStyleBackColor = true;
            this.lastFirstMidButton.Click += new System.EventHandler(this.lastFirstMidButton_Click);
            // 
            // lastFirstButton
            // 
            this.lastFirstButton.Location = new System.Drawing.Point(162, 269);
            this.lastFirstButton.Name = "lastFirstButton";
            this.lastFirstButton.Size = new System.Drawing.Size(128, 23);
            this.lastFirstButton.TabIndex = 10;
            this.lastFirstButton.Text = "Last, First";
            this.lastFirstButton.UseVisualStyleBackColor = true;
            this.lastFirstButton.Click += new System.EventHandler(this.lastFirstButton_Click);
            // 
            // clearButton
            // 
            this.clearButton.Location = new System.Drawing.Point(37, 314);
            this.clearButton.Name = "clearButton";
            this.clearButton.Size = new System.Drawing.Size(65, 35);
            this.clearButton.TabIndex = 11;
            this.clearButton.Text = "Clear";
            this.clearButton.UseVisualStyleBackColor = true;
            this.clearButton.Click += new System.EventHandler(this.clearButton_Click);
            // 
            // exitButton
            // 
            this.exitButton.Location = new System.Drawing.Point(180, 314);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(75, 35);
            this.exitButton.TabIndex = 12;
            this.exitButton.Text = "Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // outputLabel
            // 
            this.outputLabel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.outputLabel.Location = new System.Drawing.Point(37, 140);
            this.outputLabel.Name = "outputLabel";
            this.outputLabel.Size = new System.Drawing.Size(243, 23);
            this.outputLabel.TabIndex = 17;
            this.outputLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(318, 382);
            this.Controls.Add(this.outputLabel);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.clearButton);
            this.Controls.Add(this.lastFirstButton);
            this.Controls.Add(this.lastFirstMidButton);
            this.Controls.Add(this.lastFirstMidTitleButton);
            this.Controls.Add(this.firstLastButton);
            this.Controls.Add(this.FirstMidLastButton);
            this.Controls.Add(this.titleFirstMidLastButton);
            this.Controls.Add(this.lastNameTextBox);
            this.Controls.Add(this.titleTextBox);
            this.Controls.Add(this.middleNameTextBox);
            this.Controls.Add(this.firstnameTextBox);
            this.Controls.Add(this.titleLabel);
            this.Controls.Add(this.middleNamePromptLabel);
            this.Controls.Add(this.lastNamePromptLabel);
            this.Controls.Add(this.FirstNamePromptLabel);
            this.Name = "Form1";
            this.Text = "Name Formatter";
            this.TopMost = true;
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label FirstNamePromptLabel;
        private System.Windows.Forms.Label lastNamePromptLabel;
        private System.Windows.Forms.Label middleNamePromptLabel;
        private System.Windows.Forms.Label titleLabel;
        private System.Windows.Forms.TextBox firstnameTextBox;
        private System.Windows.Forms.TextBox middleNameTextBox;
        private System.Windows.Forms.TextBox titleTextBox;
        private System.Windows.Forms.TextBox lastNameTextBox;
        private System.Windows.Forms.Button titleFirstMidLastButton;
        private System.Windows.Forms.Button FirstMidLastButton;
        private System.Windows.Forms.Button firstLastButton;
        private System.Windows.Forms.Button lastFirstMidTitleButton;
        private System.Windows.Forms.Button lastFirstMidButton;
        private System.Windows.Forms.Button lastFirstButton;
        private System.Windows.Forms.Button clearButton;
        private System.Windows.Forms.Button exitButton;
        private System.Windows.Forms.Label outputLabel;
    }
}

