﻿/**
* 01/31/2018
* CSC 153
* Gabriela Canjura
* Person selects a card and the program tells them what the card is that they chose
*/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace M1HW2_Canjura
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void diamondsPictureBox_Click(object sender, EventArgs e)
        {
            answerLabel.Text = "Eight of Diamonds";
        }

        private void Clubs2PictureBox_Click(object sender, EventArgs e)
        {
            answerLabel.Text = "Two of Clubs";
        }

        private void kSpadesPicturebox_Click(object sender, EventArgs e)
        {
            answerLabel.Text = "King of Spades";
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            answerLabel.Text = "Ace of Spades";
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            answerLabel.Text = "Joker";
        }
    }
}
