﻿namespace M1HW2_Canjura
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.exitButton = new System.Windows.Forms.Button();
            this.answerLabel = new System.Windows.Forms.Label();
            this.diamondsPictureBox = new System.Windows.Forms.PictureBox();
            this.Clubs2PictureBox = new System.Windows.Forms.PictureBox();
            this.kSpadesPicturebox = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.displayLabel = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.diamondsPictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Clubs2PictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.kSpadesPicturebox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.SuspendLayout();
            // 
            // exitButton
            // 
            this.exitButton.Location = new System.Drawing.Point(521, 437);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(75, 23);
            this.exitButton.TabIndex = 0;
            this.exitButton.Text = "Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // answerLabel
            // 
            this.answerLabel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.answerLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.answerLabel.Location = new System.Drawing.Point(334, 373);
            this.answerLabel.Name = "answerLabel";
            this.answerLabel.Size = new System.Drawing.Size(460, 38);
            this.answerLabel.TabIndex = 1;
            this.answerLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // diamondsPictureBox
            // 
            this.diamondsPictureBox.Image = ((System.Drawing.Image)(resources.GetObject("diamondsPictureBox.Image")));
            this.diamondsPictureBox.Location = new System.Drawing.Point(12, 79);
            this.diamondsPictureBox.Name = "diamondsPictureBox";
            this.diamondsPictureBox.Size = new System.Drawing.Size(201, 253);
            this.diamondsPictureBox.TabIndex = 2;
            this.diamondsPictureBox.TabStop = false;
            this.diamondsPictureBox.Click += new System.EventHandler(this.diamondsPictureBox_Click);
            // 
            // Clubs2PictureBox
            // 
            this.Clubs2PictureBox.Image = ((System.Drawing.Image)(resources.GetObject("Clubs2PictureBox.Image")));
            this.Clubs2PictureBox.Location = new System.Drawing.Point(248, 79);
            this.Clubs2PictureBox.Name = "Clubs2PictureBox";
            this.Clubs2PictureBox.Size = new System.Drawing.Size(202, 253);
            this.Clubs2PictureBox.TabIndex = 3;
            this.Clubs2PictureBox.TabStop = false;
            this.Clubs2PictureBox.Click += new System.EventHandler(this.Clubs2PictureBox_Click);
            // 
            // kSpadesPicturebox
            // 
            this.kSpadesPicturebox.Image = ((System.Drawing.Image)(resources.GetObject("kSpadesPicturebox.Image")));
            this.kSpadesPicturebox.Location = new System.Drawing.Point(467, 79);
            this.kSpadesPicturebox.Name = "kSpadesPicturebox";
            this.kSpadesPicturebox.Size = new System.Drawing.Size(199, 253);
            this.kSpadesPicturebox.TabIndex = 4;
            this.kSpadesPicturebox.TabStop = false;
            this.kSpadesPicturebox.Click += new System.EventHandler(this.kSpadesPicturebox_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(698, 79);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(201, 253);
            this.pictureBox1.TabIndex = 5;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(923, 79);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(202, 253);
            this.pictureBox2.TabIndex = 6;
            this.pictureBox2.TabStop = false;
            this.pictureBox2.Click += new System.EventHandler(this.pictureBox2_Click);
            // 
            // displayLabel
            // 
            this.displayLabel.AutoSize = true;
            this.displayLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.displayLabel.Location = new System.Drawing.Point(410, 20);
            this.displayLabel.Name = "displayLabel";
            this.displayLabel.Size = new System.Drawing.Size(256, 24);
            this.displayLabel.TabIndex = 7;
            this.displayLabel.Text = "Click a Card to See It\'s Name!";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1162, 521);
            this.Controls.Add(this.displayLabel);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.kSpadesPicturebox);
            this.Controls.Add(this.Clubs2PictureBox);
            this.Controls.Add(this.diamondsPictureBox);
            this.Controls.Add(this.answerLabel);
            this.Controls.Add(this.exitButton);
            this.Name = "Form1";
            this.Text = "Card Identifier";
            ((System.ComponentModel.ISupportInitialize)(this.diamondsPictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Clubs2PictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.kSpadesPicturebox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button exitButton;
        private System.Windows.Forms.Label answerLabel;
        private System.Windows.Forms.PictureBox diamondsPictureBox;
        private System.Windows.Forms.PictureBox Clubs2PictureBox;
        private System.Windows.Forms.PictureBox kSpadesPicturebox;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Label displayLabel;
    }
}

