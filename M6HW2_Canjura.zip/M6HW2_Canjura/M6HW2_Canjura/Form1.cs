﻿/**
* 04/18/2016
* CSC 153
* Gabriela Canjura
* calculates the total cost for services and parts and part tax
*/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace M6HW2_Canjura
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private decimal OilLubeCharges() // calculates amount for checked boxes
        {
            decimal total = 0;

            if (oilCheckBox.Checked)
            {
                total += 26.00M;
            }
            if (lubeCheckBox.Checked)
            {
                total += 18.00M;
            }

            return total;
        }

        private decimal FlushCharges()
        {
            decimal total = 0;

            if (radiatorCheckBox.Checked)
            {
                total += 30.00m;
            }
            if (transmissionCheckBox.Checked)
            {
                total += 80.00M;
            }

            return total;
        }

        private decimal MiscCharges()
        {
            decimal total = 0;

            if (inspectionCheckBox.Checked)
            {
                total += 15.00M;
            }
            if (mufflerCheckBox.Checked)
            {
                total += 100.00M;
            }
            if (tireCheckBox.Checked)
            {
                total += 20.00M;
            }

            return total;
        }

        private decimal OtherCharges(decimal subtotal) //calculates amount and tax for text boxes
        {
            decimal parts;
            decimal labor;

            // masked text box only allows user to enter specified data

            if (partsMaskedTextBox.Text == "" || laborMaskedTextBox.Text == "") // assigns a value if nothing entered in boxes
            {
                parts = 0M;
                labor = 0M;
            }
            else
            {
                parts = decimal.Parse(partsMaskedTextBox.Text);
                labor = decimal.Parse(laborMaskedTextBox.Text);
            }

            partsLabel.Text = parts.ToString("c");
            subtotal += labor;

            serviceLabel.Text = subtotal.ToString();
     
            return parts;
        }

        private decimal TaxCharges(decimal subtotal)
        {
            decimal parts = 0M;
            decimal tax = 0M;
            decimal partsAndTax;

            parts = OtherCharges(subtotal);

            tax = parts * (.06M);
            partsAndTax = parts + tax;

            taxLabel.Text = tax.ToString("c");

            return partsAndTax;
        }

        private void TotalCharges()
        {
            decimal subtotal = 0M;
            decimal grandTotal = 0M;
            decimal tax = 0M;

            subtotal += OilLubeCharges();
            subtotal += FlushCharges();
            subtotal += MiscCharges();
            tax = TaxCharges(subtotal);

            //parses text in label to a number 
            subtotal = decimal.Parse(serviceLabel.Text);

            grandTotal = subtotal + tax;

            serviceLabel.Text = subtotal.ToString("c"); // formats subtotal to currency

            feesLabel.Text = grandTotal.ToString("c");

        }

        private void calculateButton_Click(object sender, EventArgs e)
        {
            TotalCharges();
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void clearButton_Click(object sender, EventArgs e)
        {
            //uses methods to clear out all fields
            ClearOilLube();
            ClearFlushes();
            ClearMisc();
            ClearOther();
            ClearFees();
        }

        void ClearOilLube()
        {
            oilCheckBox.Checked = false;
            lubeCheckBox.Checked = false;
        }

        void ClearFlushes()
        {
            radiatorCheckBox.Checked = false;
            transmissionCheckBox.Checked = false;
        }

        void ClearMisc()
        {
            inspectionCheckBox.Checked = false;
            mufflerCheckBox.Checked = false;
            tireCheckBox.Checked = false;
        }

        void ClearOther()
        {
            partsMaskedTextBox.Text = "";
            laborMaskedTextBox.Text = ""; 
        }

        void ClearFees()
        {
            serviceLabel.Text = "";
            partsLabel.Text = "";
            taxLabel.Text = "";
            feesLabel.Text = "";
        }
    }
}
