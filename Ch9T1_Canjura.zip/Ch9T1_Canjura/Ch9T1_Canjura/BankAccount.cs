﻿/**
* 05/02/2018
* CSC 153
* Gabriela Canjura  
* adds and subtracts money from balance using a class
*/

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ch9T1_Canjura
{
    class BankAccount
    {
        //Field
        private decimal _balance;

        //Counstructor
        public BankAccount (decimal startingBalance)
        {
            _balance = startingBalance;
        }

        //balance property(read-only)
        public decimal Balance
        {
            get { return _balance; }
        }

        //Deposit Method
        public void Deposit(decimal amount)
        {
            _balance += amount;
        }

        //withdrawl method
        public void Withdraw(decimal amount)
        {
            _balance -= amount;
        }
    }
}
