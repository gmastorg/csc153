﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace M6HW3_Group2
{
    public partial class winnerForm : Form
    {
       //receives user and computer variables to use
        public winnerForm(int user, int computer)
        {
            InitializeComponent();
            decision(user, computer); // calls method that determines the winner
        }

        public void decision(int user, int computer)
        { 
            if (computer == user) // decides if the user and computer tied
            {
                outputLabel.Text = ("You Tied!!");
                userPictureBox.Image = imageList.Images[user - 1];
                computerPictureBox.Image = imageList.Images[user - 1];
            }
            else
            {
                switch (computer) // compares selection from computer to selection from user 
                {
                    case 1:
                        if (user == 2 || user == 5)
                        {
                            outputLabel.Text = ("You Won!!");
                            userPictureBox.Image = imageList.Images[user - 1];
                            computerPictureBox.Image = imageList.Images[computer - 1];
                        }
                        if (user == 3 || user == 4)
                        {
                            outputLabel.Text = ("You Lose!!");
                            userPictureBox.Image = imageList.Images[user - 1];
                            computerPictureBox.Image = imageList.Images[computer - 1];
                        }
                        break;
                    case 2:
                        if (user == 1 || user == 5)
                        {
                            outputLabel.Text = ("You Lose!!");
                            userPictureBox.Image = imageList.Images[user - 1];
                            computerPictureBox.Image = imageList.Images[computer - 1];
                        }
                        if (user == 3 || user == 4)
                        {
                            outputLabel.Text = ("You Win!!");
                            userPictureBox.Image = imageList.Images[user - 1];
                            computerPictureBox.Image = imageList.Images[computer - 1];
                        }
                        break;
                    case 3:
                        if (user == 1 || user == 5)
                        {
                            outputLabel.Text = ("You Won!!");
                            userPictureBox.Image = imageList.Images[user - 1];
                            computerPictureBox.Image = imageList.Images[computer - 1];
                        }
                        if (user == 2 || user == 4)
                        {
                            outputLabel.Text = ("You Lose!!");
                            userPictureBox.Image = imageList.Images[user - 1];
                            computerPictureBox.Image = imageList.Images[computer - 1];
                        }
                        break;
                    case 4:
                        if (user == 1 || user == 3)
                        {
                            outputLabel.Text = ("You Won!!");
                            userPictureBox.Image = imageList.Images[user - 1];
                            computerPictureBox.Image = imageList.Images[computer - 1];
                        }
                        if (user == 2 || user == 5)
                        {
                            outputLabel.Text = ("You Lose!!");
                            userPictureBox.Image = imageList.Images[user - 1];
                            computerPictureBox.Image = imageList.Images[computer - 1];
                        }
                        break;
                    case 5:
                        if (user == 2 || user == 4)
                        {
                            outputLabel.Text = ("You Won!!");
                            userPictureBox.Image = imageList.Images[user - 1];
                            computerPictureBox.Image = imageList.Images[computer - 1];
                        }
                        if (user == 1 || user == 3)
                        {
                            outputLabel.Text = ("You Lose!!");
                            userPictureBox.Image = imageList.Images[user - 1];
                            computerPictureBox.Image = imageList.Images[computer - 1];
                        }
                        break;
                    default:
                        break;
                }
            }    
        }
    }
}
