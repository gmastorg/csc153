﻿/**
* 04/19/2018
* CSC 153
* Group 2
* has user play rock paper scissors lizard spock against computer
*/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace M6HW3_Group2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        // gets the second form and passes variable user to form
        // selects random choice for computer
        public void winner(int user)
        {
            int computer;

            //creates a random object
            Random number = new Random();
            //selects a random number 1-5
            computer = number.Next(1, 6);

            //gets the second form
            winnerForm win = new winnerForm(user, computer);
            //shows the second form. will not let user click on first form until second is closed
            win.ShowDialog(); 
            
        }

        // for all below when picture is clicked it assigns a number to user 
        // and passes user to method winner
        public void rockPictureBox_Click(object sender, EventArgs e)
        {
            int user;

            user = 1;
            winner(user);
        }

        public void paperPictureBox_Click(object sender, EventArgs e)
        {
            int user;

            user = 2;

            winner(user);
        }

        public void scissorsPictureBox_Click(object sender, EventArgs e)
        {
            int user;

            user = 3;

            winner(user);
        }

        public void lizardPictureBox_Click(object sender, EventArgs e)
        {
            int user;

            user = 4;

            winner(user);
        }

        public void spockPictureBox_Click(object sender, EventArgs e)
        {
            int user;

            user = 5;

            winner(user);
        }
    }
}
