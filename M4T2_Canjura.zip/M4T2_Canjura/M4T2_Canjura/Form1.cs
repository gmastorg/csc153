﻿/**
* 03/12/2018
* CSC 153
* Gabriela Canjura
* obtains info from a file and writes it to a list box
*/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace M4T2_Canjura
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void getCountriesButton_Click(object sender, EventArgs e)
        {
            try
            {
                //declare variable to hold country name.
                string countryName;

                // declare StreamReader Variable
                StreamReader inputFile;

                //open the file and get a StreamReader object
                inputFile = File.OpenText("Countries.txt");

                // clear anything currently in the ListBox.
                countriesListBox.Items.Clear();
                
                // read the file's contents
                while (!inputFile.EndOfStream)
                {
                    //get country name.
                    countryName = inputFile.ReadLine();

                    //add the country name to the ListBox.
                    countriesListBox.Items.Add(countryName);
                }

                //close the file 
                inputFile.Close();
            }
            catch (Exception ex)
            {
                //Display an error message
                MessageBox.Show(ex.Message);
            }
        }
        private void exitButton_Click(object sender, EventArgs e)
        {
            //close the form
            this.Close();
        }
    }
}
