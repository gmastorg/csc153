﻿/**
* 05/11/2018
* CSC 153
* Gabriela Canjura
* Has user select a dorm and a meal plan then gives them the total
* in another  form. 
* defaults to Allen Hall and 7 week meal plan
*/


using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ch9HW3_Canjura
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        // method used to calculate cost of dorm
        public double getDormCost()
        {
            double total = 0;

            if (allenRadioButton.Checked)
                {
                total = 1500;
                }
            if (pikeRadioButton.Checked)
            {
                total = 1600;
            }
            if (farthingRadioButton.Checked)
            {
                total = 1800;
            }
            if (universityRadioButton.Checked)
            {
                total = 2500;
            }
            return total; 
        }

        //method used to store name of dorm selected
        public string getDorm()
        {
            string dorm = " ";

            if (allenRadioButton.Checked)
            {
                dorm = "Allen Hall";
            }
            if (pikeRadioButton.Checked)
            {
                dorm = "Pike Hall";
            }
            if (farthingRadioButton.Checked)
            {
                dorm = "Farthing Hall";
            }
            if (universityRadioButton.Checked)
            {
                dorm = "University Suites";
            }
            return dorm;
        }

        //method to calculate cost of meal plan
        public double getMealPlanCost()
        {
            double total = 0;

            if (sevenRadioButton.Checked)
            {
                total = 600;
            }
            if (fourteenRadioButton.Checked)
            {
                total = 1200;
            }
            if (unlimitedRadioButton.Checked)
            {
                total = 1700;
            }
           
            return total;
        }

        //method used to get name meal plan
        public string getMealPlan()
        {
            string mealPlan = " ";

            if (sevenRadioButton.Checked)
            {
                mealPlan = "7 meals per week";
            }
            if (fourteenRadioButton.Checked)
            {
                mealPlan = "14 meals per week";
            }
            if (unlimitedRadioButton.Checked)
            {
                mealPlan = "Unlimited meals";
            }
            return mealPlan;
        }
        
        private void totalButton_Click(object sender, EventArgs e)
        {
            double total = getDormCost();
            total += getMealPlanCost();

            string dorm = getDorm();
            string mealPlan = getMealPlan();

            //calls second form
            Total totalForm = new Total();
            // allows for use of total, dorm
            //and meal plan that were obtained here to be used 
            // in total form
            totalForm.total = total;
            totalForm.dorm = dorm;
            totalForm.mealPlan = mealPlan;
            //shows form
            totalForm.ShowDialog();
            
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            // closes form
            this.Close();
        }
    }
}
