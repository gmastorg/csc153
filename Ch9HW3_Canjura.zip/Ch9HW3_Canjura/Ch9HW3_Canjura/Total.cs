﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ch9HW3_Canjura
{
    public partial class Total : Form
    {
        //total property
        public double total { get; set; }
        //dorm property
        public string dorm { get; set; }
        //mealPlan property
        public string mealPlan { get; set; }

        public Total()
        {
            InitializeComponent();
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            //closes form
            this.Close();
        }

        public void Total_Load(object sender, EventArgs e)
        {
            //displays when form is loaded
            outputLabel.Text = "The cost for "+this.dorm+" with "+this.mealPlan+" is "
                + this.total.ToString("c") + " per semester.";
        }
    }
}
