﻿namespace Ch9HW3_Canjura
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dormitoriesGroupBox = new System.Windows.Forms.GroupBox();
            this.mealPlanGroupBox = new System.Windows.Forms.GroupBox();
            this.totalButton = new System.Windows.Forms.Button();
            this.exitButton = new System.Windows.Forms.Button();
            this.allenRadioButton = new System.Windows.Forms.RadioButton();
            this.pikeRadioButton = new System.Windows.Forms.RadioButton();
            this.farthingRadioButton = new System.Windows.Forms.RadioButton();
            this.universityRadioButton = new System.Windows.Forms.RadioButton();
            this.sevenRadioButton = new System.Windows.Forms.RadioButton();
            this.fourteenRadioButton = new System.Windows.Forms.RadioButton();
            this.unlimitedRadioButton = new System.Windows.Forms.RadioButton();
            this.dormitoriesGroupBox.SuspendLayout();
            this.mealPlanGroupBox.SuspendLayout();
            this.SuspendLayout();
            // 
            // dormitoriesGroupBox
            // 
            this.dormitoriesGroupBox.Controls.Add(this.universityRadioButton);
            this.dormitoriesGroupBox.Controls.Add(this.farthingRadioButton);
            this.dormitoriesGroupBox.Controls.Add(this.pikeRadioButton);
            this.dormitoriesGroupBox.Controls.Add(this.allenRadioButton);
            this.dormitoriesGroupBox.Location = new System.Drawing.Point(22, 39);
            this.dormitoriesGroupBox.Name = "dormitoriesGroupBox";
            this.dormitoriesGroupBox.Size = new System.Drawing.Size(155, 119);
            this.dormitoriesGroupBox.TabIndex = 0;
            this.dormitoriesGroupBox.TabStop = false;
            this.dormitoriesGroupBox.Text = "Dormitories";
            // 
            // mealPlanGroupBox
            // 
            this.mealPlanGroupBox.Controls.Add(this.unlimitedRadioButton);
            this.mealPlanGroupBox.Controls.Add(this.fourteenRadioButton);
            this.mealPlanGroupBox.Controls.Add(this.sevenRadioButton);
            this.mealPlanGroupBox.Location = new System.Drawing.Point(194, 39);
            this.mealPlanGroupBox.Name = "mealPlanGroupBox";
            this.mealPlanGroupBox.Size = new System.Drawing.Size(170, 119);
            this.mealPlanGroupBox.TabIndex = 1;
            this.mealPlanGroupBox.TabStop = false;
            this.mealPlanGroupBox.Text = "Meal Plans";
            // 
            // totalButton
            // 
            this.totalButton.Location = new System.Drawing.Point(58, 184);
            this.totalButton.Name = "totalButton";
            this.totalButton.Size = new System.Drawing.Size(75, 23);
            this.totalButton.TabIndex = 2;
            this.totalButton.Text = "Total";
            this.totalButton.UseVisualStyleBackColor = true;
            this.totalButton.Click += new System.EventHandler(this.totalButton_Click);
            // 
            // exitButton
            // 
            this.exitButton.Location = new System.Drawing.Point(234, 184);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(75, 23);
            this.exitButton.TabIndex = 3;
            this.exitButton.Text = "Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // allenRadioButton
            // 
            this.allenRadioButton.AutoSize = true;
            this.allenRadioButton.Checked = true;
            this.allenRadioButton.Location = new System.Drawing.Point(6, 19);
            this.allenRadioButton.Name = "allenRadioButton";
            this.allenRadioButton.Size = new System.Drawing.Size(69, 17);
            this.allenRadioButton.TabIndex = 4;
            this.allenRadioButton.TabStop = true;
            this.allenRadioButton.Text = "Allen Hall";
            this.allenRadioButton.UseVisualStyleBackColor = true;
            // 
            // pikeRadioButton
            // 
            this.pikeRadioButton.AutoSize = true;
            this.pikeRadioButton.Location = new System.Drawing.Point(7, 43);
            this.pikeRadioButton.Name = "pikeRadioButton";
            this.pikeRadioButton.Size = new System.Drawing.Size(67, 17);
            this.pikeRadioButton.TabIndex = 5;
            this.pikeRadioButton.TabStop = true;
            this.pikeRadioButton.Text = "Pike Hall";
            this.pikeRadioButton.UseVisualStyleBackColor = true;
            // 
            // farthingRadioButton
            // 
            this.farthingRadioButton.AutoSize = true;
            this.farthingRadioButton.Location = new System.Drawing.Point(7, 67);
            this.farthingRadioButton.Name = "farthingRadioButton";
            this.farthingRadioButton.Size = new System.Drawing.Size(84, 17);
            this.farthingRadioButton.TabIndex = 6;
            this.farthingRadioButton.TabStop = true;
            this.farthingRadioButton.Text = "Farthing Hall";
            this.farthingRadioButton.UseVisualStyleBackColor = true;
            // 
            // universityRadioButton
            // 
            this.universityRadioButton.AutoSize = true;
            this.universityRadioButton.Location = new System.Drawing.Point(7, 96);
            this.universityRadioButton.Name = "universityRadioButton";
            this.universityRadioButton.Size = new System.Drawing.Size(103, 17);
            this.universityRadioButton.TabIndex = 7;
            this.universityRadioButton.TabStop = true;
            this.universityRadioButton.Text = "University Suites";
            this.universityRadioButton.UseVisualStyleBackColor = true;
            // 
            // sevenRadioButton
            // 
            this.sevenRadioButton.AutoSize = true;
            this.sevenRadioButton.Checked = true;
            this.sevenRadioButton.Location = new System.Drawing.Point(7, 19);
            this.sevenRadioButton.Name = "sevenRadioButton";
            this.sevenRadioButton.Size = new System.Drawing.Size(108, 17);
            this.sevenRadioButton.TabIndex = 0;
            this.sevenRadioButton.TabStop = true;
            this.sevenRadioButton.Text = "7 meals per week";
            this.sevenRadioButton.UseVisualStyleBackColor = true;
            // 
            // fourteenRadioButton
            // 
            this.fourteenRadioButton.AutoSize = true;
            this.fourteenRadioButton.Location = new System.Drawing.Point(6, 56);
            this.fourteenRadioButton.Name = "fourteenRadioButton";
            this.fourteenRadioButton.Size = new System.Drawing.Size(114, 17);
            this.fourteenRadioButton.TabIndex = 1;
            this.fourteenRadioButton.TabStop = true;
            this.fourteenRadioButton.Text = "14 meals per week";
            this.fourteenRadioButton.UseVisualStyleBackColor = true;
            // 
            // unlimitedRadioButton
            // 
            this.unlimitedRadioButton.AutoSize = true;
            this.unlimitedRadioButton.Location = new System.Drawing.Point(7, 96);
            this.unlimitedRadioButton.Name = "unlimitedRadioButton";
            this.unlimitedRadioButton.Size = new System.Drawing.Size(98, 17);
            this.unlimitedRadioButton.TabIndex = 2;
            this.unlimitedRadioButton.TabStop = true;
            this.unlimitedRadioButton.Text = "Unlimited meals";
            this.unlimitedRadioButton.UseVisualStyleBackColor = true;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(386, 246);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.totalButton);
            this.Controls.Add(this.mealPlanGroupBox);
            this.Controls.Add(this.dormitoriesGroupBox);
            this.Name = "Form1";
            this.Text = "Dorm and Meal Plan Calculator";
            this.dormitoriesGroupBox.ResumeLayout(false);
            this.dormitoriesGroupBox.PerformLayout();
            this.mealPlanGroupBox.ResumeLayout(false);
            this.mealPlanGroupBox.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox dormitoriesGroupBox;
        private System.Windows.Forms.GroupBox mealPlanGroupBox;
        private System.Windows.Forms.Button totalButton;
        private System.Windows.Forms.Button exitButton;
        private System.Windows.Forms.RadioButton universityRadioButton;
        private System.Windows.Forms.RadioButton farthingRadioButton;
        private System.Windows.Forms.RadioButton pikeRadioButton;
        private System.Windows.Forms.RadioButton allenRadioButton;
        private System.Windows.Forms.RadioButton unlimitedRadioButton;
        private System.Windows.Forms.RadioButton fourteenRadioButton;
        private System.Windows.Forms.RadioButton sevenRadioButton;
    }
}

