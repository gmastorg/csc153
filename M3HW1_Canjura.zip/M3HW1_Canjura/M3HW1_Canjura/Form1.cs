﻿/**
* 02/26/2018
* CSC 153
* Gabriela Canjura
* converts intigers 1-10 to roman numerals using switch decision making structure
*/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace M3HW1_Canjura
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void convertButton_Click(object sender, EventArgs e)
        {
            int num;
            int.TryParse(intigerTextBox.Text, out num); // validates input to make sure it can be parsed into a string
            
            switch (num) // decision making structure that compares input in variable to the different cases presented
            {
                case 1: // if num = to 1 then this will execute
                    outputLabel.Text = "I";
                    break;
                case 2: // if num = to 2 then this will execute and so on for following
                    outputLabel.Text = "II";
                    break;
                case 3:
                    outputLabel.Text = "III";
                    break;
                case 4:
                    outputLabel.Text = "IV";
                    break;
                case 5:
                    outputLabel.Text = "V";
                    break;
                case 6:
                    outputLabel.Text = "VI";
                    break;
                case 7:
                    outputLabel.Text = "VII";
                    break;
                case 8:
                    outputLabel.Text = "VII";
                    break;
                case 9:
                    outputLabel.Text = "IX";
                    break;
                case 10:
                    outputLabel.Text = "X";
                    break;
                default:// will display if input is not an intiger 1-10 
                    MessageBox.Show ("Invalid input. Make sure you are entering an integer 1-10.");
                    break;
            }
        }

        private void exitButton_Click(object sender, EventArgs e) // closes 
        {
            this.Close();
        }

        private void clearButton_Click(object sender, EventArgs e) // clears text box and output label
        {
            intigerTextBox.Text = "";
            outputLabel.Text = "";
        }
    }
}
