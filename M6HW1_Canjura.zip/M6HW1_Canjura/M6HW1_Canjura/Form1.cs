﻿/**
* 04/16/2018
* CSC 153
* Gabriela Canjura
* calculates falling distance using methods
*/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace M6HW1_Canjura
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        
        // method to verify input and call calculation method
        private void InputIsValid()
        {
            double time;

            if (double.TryParse(timeTextBox.Text, out time))
            {  
                FallingDistance(time); // calls method and passes time to method
            }
            else
            {
                MessageBox.Show("Time entered incorrectly. Please use numbers.");
            }
        }   
        
        //calculates distance
        private void FallingDistance(double time)
        {
            double distance = 0;

            distance = (.5)*9.8 *Math.Pow(time,2); // calculates distance = 1/2gt^2

            outputLabel.Text = distance.ToString()+" m"; // makes answer a string to display
        }

        private void calculateButton_Click(object sender, EventArgs e)
        {
            InputIsValid(); // calls the input validation method
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close(); // closes form
        }

        private void clearButton_Click(object sender, EventArgs e)
        {
            //clears text box and output label 

            timeTextBox.Text = "";
            outputLabel.Text = "";
        }
    }
}
