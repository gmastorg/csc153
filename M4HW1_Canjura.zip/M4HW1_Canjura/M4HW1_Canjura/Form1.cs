﻿/**
* 03/19/2018
* CSC 153
* Gabriela Canjura
* calculates population growth
*/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace M4HW1_Canjura
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void calculateGrowthButton_Click(object sender, EventArgs e)
        {
            //declares variables
            double organisms; 
            double percent;
            int days;
            int count = 1;
            double growth;

            try
            {
                //parses organisms into double
                organisms = double.Parse(numOfOrgsTextBox.Text);
                //Parses percent to double and turns it into decimal
                percent = double.Parse(percentTextBox.Text) / 100;
                //Parses days to int
                days = int.Parse(daysTextBox.Text);
                // assigns organism value to growth
                growth = organisms;

                //creates a header for output list
                outputListBox.Items.Add("Days\tApproximate Population ");
                outputListBox.Items.Add("-----------------------------------------------------");
                //displays day 1 count as organisms amount entered bc no growth has occured yet
                outputListBox.Items.Add(count+ "\t" +growth);
                // adds one to count
                count++;
               
                while (count <= days) // runs loop while count less than or equal to days
                    {
                        growth = growth * (1 + percent); // calculates growth
                        outputListBox.Items.Add(count + "\t" + growth); // prints count and growth to list
                        count++; //adds one to loop
                    }
            }
            catch(Exception ex)
            {
                //display error message
                MessageBox.Show(ex.Message);
            }
            
        }

        private void clearButton_Click(object sender, EventArgs e)
        {
            //clears list box
            outputListBox.Items.Clear();
            //clears textboxes
            numOfOrgsTextBox.Text = " ";
            percentTextBox.Text = " ";
            daysTextBox.Text = " "; 
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            // close the form
            this.Close();
        }
    }
}
