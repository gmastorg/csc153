﻿/**
* 02/14/2018
* CSC 153
* Gabriela Canjura
* Creates a sentence from buttons clicked
*/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace M2HW2_Canjura
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        private string word; //variable to holds the previously clicked buttons

        /* Methods below takes contents held in word and adds new info, displays it, and holds to word. 
         * It is adding the text within the "" to be displayed. This is done for the methods below until reaching clear button.
        */
         
        private void Abutton_Click(object sender, EventArgs e)
        {
          
            outputLabel.Text= word += ("A"); 
        }

        private void lowerAButton_Click(object sender, EventArgs e)
        {
            outputLabel.Text = word += ("a");
        }

        private void upperAnButton_Click(object sender, EventArgs e)
        {
            outputLabel.Text = word += ("An");
        }

        private void lowerAnButton_Click(object sender, EventArgs e)
        {
            outputLabel.Text = word += ("an");
        }

        private void upperTheButton_Click(object sender, EventArgs e)
        {
            outputLabel.Text = word += ("The");
        }

        private void lowerTheButton_Click(object sender, EventArgs e)
        {
            outputLabel.Text = word += ("the");
        }

        private void manButton_Click(object sender, EventArgs e)
        {
            outputLabel.Text = word += ("man");
        }

        private void womanButton_Click(object sender, EventArgs e)
        {
            outputLabel.Text = word += ("woman");
        }

        private void dogButton_Click(object sender, EventArgs e)
        {
            outputLabel.Text = word += ("dog");
        }

        private void catButton_Click(object sender, EventArgs e)
        {
            outputLabel.Text = word += ("cat");
        }

        private void carButton_Click(object sender, EventArgs e)
        {
            outputLabel.Text = word += ("car");
        }

        private void bicycleButton_Click(object sender, EventArgs e)
        {
            outputLabel.Text = word += ("bicycle");
        }

        private void beautifulButton_Click(object sender, EventArgs e)
        {
            outputLabel.Text = word += ("beautiful");
        }

        private void bigButton_Click(object sender, EventArgs e)
        {
            outputLabel.Text = word += ("big");
        }

        private void smallButton_Click(object sender, EventArgs e)
        {
            outputLabel.Text = word += ("small");
        }

        private void strangebutton_Click(object sender, EventArgs e)
        {
            outputLabel.Text = word += ("strange");
        }

        private void lookedAtButton_Click(object sender, EventArgs e)
        {
            outputLabel.Text = word += ("looked at");
        }

        private void rodeButton_Click(object sender, EventArgs e)
        {
            outputLabel.Text = word += ("rode");
        }

        private void spokeToButton_Click(object sender, EventArgs e)
        {
            outputLabel.Text = word += ("spoke to");
        }

        private void laughedAtButton_Click(object sender, EventArgs e)
        {
            outputLabel.Text = word += ("laughed at");
        }

        private void droveButton_Click(object sender, EventArgs e)
        {
            outputLabel.Text = word += ("drove");
        }

        private void spaceButton_Click(object sender, EventArgs e)
        {
            outputLabel.Text = word += (" ");
        }

        private void periodButton_Click(object sender, EventArgs e)
        {
            outputLabel.Text = word += (".");
        }

        private void exclimationButton_Click(object sender, EventArgs e)
        {
            outputLabel.Text = word += ("!");
        }

        private void clearButton_Click(object sender, EventArgs e)
        {
            word = ""; // clears word or else it will hold it when a button is clicked after hitting clear
            outputLabel.Text = (""); //clears the output label
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close(); // closes the program
        }
    }
}
