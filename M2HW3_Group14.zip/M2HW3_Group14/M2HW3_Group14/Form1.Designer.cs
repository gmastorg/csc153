﻿namespace M2HW3_Group14
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.soldGroupBox = new System.Windows.Forms.GroupBox();
            this.displayLabel = new System.Windows.Forms.Label();
            this.classALabel = new System.Windows.Forms.Label();
            this.classATextBox = new System.Windows.Forms.TextBox();
            this.classBLabel = new System.Windows.Forms.Label();
            this.classCLabel = new System.Windows.Forms.Label();
            this.classBTextBox = new System.Windows.Forms.TextBox();
            this.classCTextBox = new System.Windows.Forms.TextBox();
            this.revenueGroupBox = new System.Windows.Forms.GroupBox();
            this.classALabel2 = new System.Windows.Forms.Label();
            this.classBLabel2 = new System.Windows.Forms.Label();
            this.classCLabel2 = new System.Windows.Forms.Label();
            this.totalLabel = new System.Windows.Forms.Label();
            this.calculateButton = new System.Windows.Forms.Button();
            this.clearButton = new System.Windows.Forms.Button();
            this.exitLabel = new System.Windows.Forms.Button();
            this.revALabel = new System.Windows.Forms.Label();
            this.revBLabel = new System.Windows.Forms.Label();
            this.revCLabel = new System.Windows.Forms.Label();
            this.totalCalcLabel = new System.Windows.Forms.Label();
            this.soldGroupBox.SuspendLayout();
            this.revenueGroupBox.SuspendLayout();
            this.SuspendLayout();
            // 
            // soldGroupBox
            // 
            this.soldGroupBox.Controls.Add(this.classCTextBox);
            this.soldGroupBox.Controls.Add(this.classBTextBox);
            this.soldGroupBox.Controls.Add(this.classCLabel);
            this.soldGroupBox.Controls.Add(this.classBLabel);
            this.soldGroupBox.Controls.Add(this.classATextBox);
            this.soldGroupBox.Controls.Add(this.classALabel);
            this.soldGroupBox.Controls.Add(this.displayLabel);
            this.soldGroupBox.Location = new System.Drawing.Point(36, 55);
            this.soldGroupBox.Name = "soldGroupBox";
            this.soldGroupBox.Size = new System.Drawing.Size(277, 199);
            this.soldGroupBox.TabIndex = 0;
            this.soldGroupBox.TabStop = false;
            this.soldGroupBox.Text = "Tickets Sold";
            // 
            // displayLabel
            // 
            this.displayLabel.AutoSize = true;
            this.displayLabel.Location = new System.Drawing.Point(9, 40);
            this.displayLabel.Name = "displayLabel";
            this.displayLabel.Size = new System.Drawing.Size(268, 13);
            this.displayLabel.TabIndex = 0;
            this.displayLabel.Text = "Enter the number of tickets sold for each class of seats.";
            // 
            // classALabel
            // 
            this.classALabel.AutoSize = true;
            this.classALabel.Location = new System.Drawing.Point(28, 79);
            this.classALabel.Name = "classALabel";
            this.classALabel.Size = new System.Drawing.Size(45, 13);
            this.classALabel.TabIndex = 1;
            this.classALabel.Text = "Class A:";
            // 
            // classATextBox
            // 
            this.classATextBox.Location = new System.Drawing.Point(79, 79);
            this.classATextBox.Name = "classATextBox";
            this.classATextBox.Size = new System.Drawing.Size(132, 20);
            this.classATextBox.TabIndex = 2;
            // 
            // classBLabel
            // 
            this.classBLabel.AutoSize = true;
            this.classBLabel.Location = new System.Drawing.Point(28, 116);
            this.classBLabel.Name = "classBLabel";
            this.classBLabel.Size = new System.Drawing.Size(45, 13);
            this.classBLabel.TabIndex = 3;
            this.classBLabel.Text = "Class B:";
            // 
            // classCLabel
            // 
            this.classCLabel.AutoSize = true;
            this.classCLabel.Location = new System.Drawing.Point(28, 155);
            this.classCLabel.Name = "classCLabel";
            this.classCLabel.Size = new System.Drawing.Size(45, 13);
            this.classCLabel.TabIndex = 4;
            this.classCLabel.Text = "Class C:";
            // 
            // classBTextBox
            // 
            this.classBTextBox.Location = new System.Drawing.Point(79, 113);
            this.classBTextBox.Name = "classBTextBox";
            this.classBTextBox.Size = new System.Drawing.Size(132, 20);
            this.classBTextBox.TabIndex = 5;
            // 
            // classCTextBox
            // 
            this.classCTextBox.Location = new System.Drawing.Point(79, 148);
            this.classCTextBox.Name = "classCTextBox";
            this.classCTextBox.Size = new System.Drawing.Size(132, 20);
            this.classCTextBox.TabIndex = 6;
            // 
            // revenueGroupBox
            // 
            this.revenueGroupBox.Controls.Add(this.totalCalcLabel);
            this.revenueGroupBox.Controls.Add(this.revCLabel);
            this.revenueGroupBox.Controls.Add(this.revBLabel);
            this.revenueGroupBox.Controls.Add(this.revALabel);
            this.revenueGroupBox.Controls.Add(this.totalLabel);
            this.revenueGroupBox.Controls.Add(this.classCLabel2);
            this.revenueGroupBox.Controls.Add(this.classBLabel2);
            this.revenueGroupBox.Controls.Add(this.classALabel2);
            this.revenueGroupBox.Location = new System.Drawing.Point(358, 55);
            this.revenueGroupBox.Name = "revenueGroupBox";
            this.revenueGroupBox.Size = new System.Drawing.Size(246, 199);
            this.revenueGroupBox.TabIndex = 1;
            this.revenueGroupBox.TabStop = false;
            this.revenueGroupBox.Text = "Revenue Generated";
            // 
            // classALabel2
            // 
            this.classALabel2.AutoSize = true;
            this.classALabel2.Location = new System.Drawing.Point(19, 47);
            this.classALabel2.Name = "classALabel2";
            this.classALabel2.Size = new System.Drawing.Size(45, 13);
            this.classALabel2.TabIndex = 2;
            this.classALabel2.Text = "Class A:";
            // 
            // classBLabel2
            // 
            this.classBLabel2.AutoSize = true;
            this.classBLabel2.Location = new System.Drawing.Point(19, 86);
            this.classBLabel2.Name = "classBLabel2";
            this.classBLabel2.Size = new System.Drawing.Size(45, 13);
            this.classBLabel2.TabIndex = 4;
            this.classBLabel2.Text = "Class B:";
            // 
            // classCLabel2
            // 
            this.classCLabel2.AutoSize = true;
            this.classCLabel2.Location = new System.Drawing.Point(19, 120);
            this.classCLabel2.Name = "classCLabel2";
            this.classCLabel2.Size = new System.Drawing.Size(45, 13);
            this.classCLabel2.TabIndex = 5;
            this.classCLabel2.Text = "Class C:";
            // 
            // totalLabel
            // 
            this.totalLabel.AutoSize = true;
            this.totalLabel.Location = new System.Drawing.Point(27, 155);
            this.totalLabel.Name = "totalLabel";
            this.totalLabel.Size = new System.Drawing.Size(37, 13);
            this.totalLabel.TabIndex = 6;
            this.totalLabel.Text = "Total: ";
            // 
            // calculateButton
            // 
            this.calculateButton.Location = new System.Drawing.Point(190, 299);
            this.calculateButton.Name = "calculateButton";
            this.calculateButton.Size = new System.Drawing.Size(75, 42);
            this.calculateButton.TabIndex = 2;
            this.calculateButton.Text = "Calculate Revenue";
            this.calculateButton.UseVisualStyleBackColor = true;
            this.calculateButton.Click += new System.EventHandler(this.calculateButton_Click);
            // 
            // clearButton
            // 
            this.clearButton.Location = new System.Drawing.Point(293, 299);
            this.clearButton.Name = "clearButton";
            this.clearButton.Size = new System.Drawing.Size(75, 42);
            this.clearButton.TabIndex = 3;
            this.clearButton.Text = "Clear";
            this.clearButton.UseVisualStyleBackColor = true;
            this.clearButton.Click += new System.EventHandler(this.clearButton_Click);
            // 
            // exitLabel
            // 
            this.exitLabel.Location = new System.Drawing.Point(388, 299);
            this.exitLabel.Name = "exitLabel";
            this.exitLabel.Size = new System.Drawing.Size(75, 42);
            this.exitLabel.TabIndex = 4;
            this.exitLabel.Text = "Exit";
            this.exitLabel.UseVisualStyleBackColor = true;
            this.exitLabel.Click += new System.EventHandler(this.exitLabel_Click);
            // 
            // revALabel
            // 
            this.revALabel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.revALabel.Location = new System.Drawing.Point(70, 46);
            this.revALabel.Name = "revALabel";
            this.revALabel.Size = new System.Drawing.Size(132, 23);
            this.revALabel.TabIndex = 11;
            // 
            // revBLabel
            // 
            this.revBLabel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.revBLabel.Location = new System.Drawing.Point(70, 81);
            this.revBLabel.Name = "revBLabel";
            this.revBLabel.Size = new System.Drawing.Size(132, 23);
            this.revBLabel.TabIndex = 12;
            // 
            // revCLabel
            // 
            this.revCLabel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.revCLabel.Location = new System.Drawing.Point(70, 115);
            this.revCLabel.Name = "revCLabel";
            this.revCLabel.Size = new System.Drawing.Size(132, 23);
            this.revCLabel.TabIndex = 13;
            // 
            // totalCalcLabel
            // 
            this.totalCalcLabel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.totalCalcLabel.Location = new System.Drawing.Point(70, 150);
            this.totalCalcLabel.Name = "totalCalcLabel";
            this.totalCalcLabel.Size = new System.Drawing.Size(132, 23);
            this.totalCalcLabel.TabIndex = 14;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(646, 386);
            this.Controls.Add(this.exitLabel);
            this.Controls.Add(this.clearButton);
            this.Controls.Add(this.calculateButton);
            this.Controls.Add(this.revenueGroupBox);
            this.Controls.Add(this.soldGroupBox);
            this.Name = "Form1";
            this.Text = "Stadium Seating";
            this.soldGroupBox.ResumeLayout(false);
            this.soldGroupBox.PerformLayout();
            this.revenueGroupBox.ResumeLayout(false);
            this.revenueGroupBox.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox soldGroupBox;
        private System.Windows.Forms.TextBox classCTextBox;
        private System.Windows.Forms.TextBox classBTextBox;
        private System.Windows.Forms.Label classCLabel;
        private System.Windows.Forms.Label classBLabel;
        private System.Windows.Forms.TextBox classATextBox;
        private System.Windows.Forms.Label classALabel;
        private System.Windows.Forms.Label displayLabel;
        private System.Windows.Forms.GroupBox revenueGroupBox;
        private System.Windows.Forms.Label totalLabel;
        private System.Windows.Forms.Label classCLabel2;
        private System.Windows.Forms.Label classBLabel2;
        private System.Windows.Forms.Label classALabel2;
        private System.Windows.Forms.Button calculateButton;
        private System.Windows.Forms.Button clearButton;
        private System.Windows.Forms.Button exitLabel;
        private System.Windows.Forms.Label revALabel;
        private System.Windows.Forms.Label totalCalcLabel;
        private System.Windows.Forms.Label revCLabel;
        private System.Windows.Forms.Label revBLabel;
    }
}

