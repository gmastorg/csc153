﻿/**
* 02/05/2018
* CSC 153
* Group 14
* calculates the revenue of stadium tickets
* Gabriela worked on the code with input from Michael
* Michael did pseudo code and flow chart 
* Anthony was not here 
*/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace M2HW3_Group14
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void calculateButton_Click(object sender, EventArgs e)
        {
            try
            {
                int tixA, tixB, tixC;   // holds entered number of tix
                decimal revA = 0m, revB = 0m, revC = 0m, total = 0m; // variables for revenue amounts displayed in variables
                decimal costA = 15.00m, costB = 12.00m, costC = 9.00m; // variables for the cost of the tickets can be changed if needed 

                tixA = int.Parse(classATextBox.Text); // takes input and parses it to an int
                tixB = int.Parse(classBTextBox.Text);
                tixC = int.Parse(classCTextBox.Text);

                revA = tixA * costA; // calculates the cost of revenue
                revB = tixB * costB;
                revC = tixC * costC;

                total = revA + revB + revC; // adds each calculated revenue to crate a grand total

                revALabel.Text = revA.ToString("c"); // displays amounts as a currency with $
                revBLabel.Text = revB.ToString("c");
                revCLabel.Text = revC.ToString("c");
                totalCalcLabel.Text = total.ToString("c");
            }

            catch (Exception ex) // catches input that is not numbers and clears input
            {
                MessageBox.Show ("Input type is invalid format.");

                classATextBox.Text = "";
                classBTextBox.Text = "";
                classCTextBox.Text = "";
            }

        }

        private void clearButton_Click(object sender, EventArgs e) // clears out input data and dicplayed data
        {
            classATextBox.Text = "";
            classBTextBox.Text = "";
            classCTextBox.Text = "";
            revALabel.Text = "";
            revBLabel.Text = "";
            revCLabel.Text = "";
            totalCalcLabel.Text = "";
        }

        private void exitLabel_Click(object sender, EventArgs e) //closes
        {
            this.Close();
        }
    }
}
