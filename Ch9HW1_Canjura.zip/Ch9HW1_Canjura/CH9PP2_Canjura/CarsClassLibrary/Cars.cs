﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CarsClassLibrary
{
    public class Cars
    {
        //Field 
        private int _year;
        private string _make;
        private int _speed;

        // Constructor
        public Cars()
        {
            _year = 0;
            _make = "";
            _speed = 0;
        }
        //year property
        public int Year
        {
            get; set;
        }
        //make property
        public string Make
        {
            get; set;
        }
        //speed property
        public int Speed
        {
            get; set;
        }
        // accelerate method
        public int accelerate(int speed)
        {
            Speed += 5;
            return Speed;
        }
        //brake method
        public int brake(int speed)
        {
            Speed -= 5;
            return Speed;
        }   
    }
}
