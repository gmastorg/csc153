﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using CarsClassLibrary;

namespace CH9PP2_Canjura
{
    public partial class Speed : Form
    {
        Cars car = new Cars();
        public Speed()
        {
            InitializeComponent();
        }

        private void enterButton_Click(object sender, EventArgs e)
        {
            int speed;

            //get car's speed
            if (int.TryParse(speedTextBox.Text, out speed))
            {
                car.Speed = speed;
                //gets the third form
                currentSpeed currentspeed = new currentSpeed();
                currentspeed.Speed = car.Speed;
                //shows the third form. Will not let user click on other forms until it is closed
                currentspeed.ShowDialog();
            }
            else
            {
                //display error
                MessageBox.Show("Invalid Speed.");
            }

            
        }
    }
}
