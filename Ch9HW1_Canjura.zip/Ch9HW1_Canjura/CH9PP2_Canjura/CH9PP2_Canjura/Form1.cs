﻿/**
* 05/09/2018
* CSC 153
* Gabriela Canjura
* uses class to obtain cars information then obtain an inital speed then accelerates and brakes displaying currrent speed each time
*/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using CarsClassLibrary;

namespace CH9PP2_Canjura
{
    public partial class Form1 : Form
    {
        List<Cars> car = new List<Cars>();
        public Form1()
        {
            InitializeComponent();
        }

        public void GetCarsData(Cars car)
        {
            // temp variable to hold year
            int year;
            
            //get car's year
            if (int.TryParse(yearTextBox.Text, out year))
            {
                car.Year = year;
            }
            else
            {
                //display error
                MessageBox.Show("Invalid Year.");
            }

            //get car make
            car.Make = makeTextBox.Text;
        }

        private void enterButton_Click(object sender, EventArgs e)
        {
            // create car object
            Cars myCar = new Cars();

            // get car data
            GetCarsData(myCar);

            //add car object to list
            car.Add(myCar);

            //Add to the listBox
            carsListBox.Items.Add(myCar.Year + "\t" + myCar.Make);

            //clear text boxes
            yearTextBox.Text = "";
            makeTextBox.Text = "";
           
            //reset focus
            yearTextBox.Focus();
        }

        private void carsListBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            //get the index of the selected item
            int index = carsListBox.SelectedIndex;

            //gets the second form
            Speed initialSpeed = new Speed();
            //shows the second form. will not let user click on first form until second is closed
            initialSpeed.ShowDialog();
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            //closes form 
            this.Close();
        }
    }
}
