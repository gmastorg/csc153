﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using CarsClassLibrary;

namespace CH9PP2_Canjura
{
    public partial class currentSpeed : Form
    {
        Cars car = new Cars();

        public int Speed { get; set; }

        public currentSpeed()
        {
            InitializeComponent();
                     
        }
       
        public void accelerateButton_Click(object sender, EventArgs e)
        {
            car.Speed = this.Speed;
            // calls accelerate function from class
            car.Speed = car.accelerate(car.Speed);

            //displays speed in list
            currentSpeedListBox.Items.Add(car.Speed);

            //prevents car.Speed from reinitializing to this.Speed from speed form
            //everytime button is clicked
            this.Speed = car.Speed;
        }

        public void brakeButton_Click(object sender, EventArgs e)
        {
            car.Speed = this.Speed;
            // calls brake function from class
            car.Speed = car.brake(car.Speed);

            // prevents speed from going into negative bc at 0 it is stopped
            if (car.Speed < 0)
            {
                car.Speed = 0;
            }
            
            //displays speed in list
            currentSpeedListBox.Items.Add(car.Speed);

            //prevents car.Speed from reinitializing to this.Speed from speed form
            //everytime button is clicked
            this.Speed = car.Speed; 
        }

        private void currentSpeed_Load(object sender, EventArgs e)
        {
            currentSpeedListBox.Items.Add("Initial speed: " + this.Speed);
        }
    }
}
