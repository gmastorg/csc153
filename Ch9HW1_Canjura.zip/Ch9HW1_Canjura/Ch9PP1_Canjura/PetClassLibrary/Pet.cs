﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PetClassLibrary
{
    public class Pet
    {

        //Field 
        private string _name;
        private string _type;
        private int _age;

        // Constructor
        public Pet()
        {
            _name = "";
            _type = "";
            _age = 0;
        }
        //Name property
        public string Name
        {
            get; set;
        }
        //type property
        public string Type
        {
            get; set;
        }
        //age property
        public int Age
        {
            get; set;
        }
    }
}
