﻿/**
* 05/09/2018
* CSC 153
* Gabriela Canjura
* creates objects for a class and then recalls information in objects and displays it
*/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using PetClassLibrary;

namespace Ch9PP1_Canjura
{
    public partial class Form1 : Form
    {
        List<Pet> animal = new List<Pet>();
        public Form1()
        {
            InitializeComponent();
        }

        private void GetPetData (Pet animal)
        {
            // temp variable to hold Age
            int age;

            //get pet's name
            animal.Name = nameTextBox.Text;

            //get pet type
            animal.Type = typeTextBox.Text;

            //get age 
            if (int.TryParse(ageTextBox.Text, out age))
            {
                animal.Age = age;
            }
            else
            {
                //display error
                MessageBox.Show("Invalid Age.");
            }
        }

        private void enterButton_Click(object sender, EventArgs e)
        {
            // create pet object
            Pet myPet = new Pet();

            // get pet data
            GetPetData(myPet);

            //add pet object to list
            animal.Add(myPet);

            //Add to the listBox
            petListBox.Items.Add(myPet.Name);

            //clear text boxes
            nameTextBox.Text = "";
            typeTextBox.Text = "";
            ageTextBox.Text = "";

            //reset focus
            nameTextBox.Focus();
        }

        private void petListBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            //get the index of the selected item
            int index = petListBox.SelectedIndex;

            // display type and age
            MessageBox.Show("Animal Type: "+ animal[index].Type + "\n Age: "+animal[index].Age.ToString());
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
