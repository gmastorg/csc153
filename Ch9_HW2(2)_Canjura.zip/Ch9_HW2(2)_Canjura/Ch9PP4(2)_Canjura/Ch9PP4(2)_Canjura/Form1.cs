﻿/**
* 05/13/2018
* CSC 153
* Gabriela Canjura
* creates an employee directory
* has 3 people pre programmed
* can have others added 
*/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using EmployeeClassLibrary;

namespace Ch9PP4_2__Canjura
{
    public partial class Form1 : Form
    {
        //creates a list
        List<EmployeeClass> employee = new List<EmployeeClass>();

        //creates 3 objects 
        EmployeeClass employee1 = new EmployeeClass();
        EmployeeClass employee2 = new EmployeeClass();
        EmployeeClass employee3 = new EmployeeClass();

        public Form1()
        {
            InitializeComponent();
        }

        // pre sets 3 objects 
        public void setEmployees()
        {
            employee1.Name = "Susan Meyers";
            employee1.IDnumber = 47899;
            employee1.Department = "Accounting";
            employee1.Position = "Vice President";

            employee2.Name = "Mark Jones";
            employee2.IDnumber = 39119;
            employee2.Department = "IT";
            employee2.Position = "Programmer";

            employee3.Name = "Joy Rogers";
            employee3.IDnumber = 81774;
            employee3.Department = "Manufacturing";
            employee3.Position = "Engineer";
        }

        public void getEmployeeData(EmployeeClass employee)
        {
            //get name
            employee.Name = nameTextBox.Text;
            //get ID Number
            employee.IDnumber = int.Parse(IDMaskedTextBox.Text);
            //get department
            employee.Department = departmentTextBox.Text;
            //get position
            employee.Position = positionTextBox.Text;
        }

        private void addButton_Click(object sender, EventArgs e)
        {
            EmployeeClass myEmployee = new EmployeeClass();
            getEmployeeData(myEmployee);
            employee.Add(myEmployee);

            outputListBox.Items.Add(myEmployee.Name + "\t" + myEmployee.IDnumber +
             "\t    " + myEmployee.Department + "\t" + myEmployee.Position);

            //clear text boxes
            nameTextBox.Text = "";
            IDMaskedTextBox.Text = "";
            departmentTextBox.Text = "";
            positionTextBox.Text = "";

            //reset focus
            nameTextBox.Focus();
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            //closes form
            this.Close();
        }

        //displays pre programmed entries and header when program loads
        private void Form1_Load(object sender, EventArgs e)
        {
            setEmployees();

            outputListBox.Items.Add("Name\t\tID Number   Department\tPosition");
            outputListBox.Items.Add("--------------------------------------" +
                "-------------------------------------------------------------------------");
            outputListBox.Items.Add(employee1.Name + "\t" + employee1.IDnumber +
             "\t    " + employee1.Department + "\t" + employee1.Position);
            //adds preprogrammed employee to list employee
            employee.Add(employee1);
            outputListBox.Items.Add(employee2.Name + "\t" + employee2.IDnumber +
             "\t    " + employee2.Department + "\t\t" + employee2.Position);
            employee.Add(employee2);
            outputListBox.Items.Add(employee3.Name + "\t" + employee3.IDnumber +
             "\t    " + employee3.Department + "\t" + employee3.Position);
            employee.Add(employee3);
        }
    }
}
