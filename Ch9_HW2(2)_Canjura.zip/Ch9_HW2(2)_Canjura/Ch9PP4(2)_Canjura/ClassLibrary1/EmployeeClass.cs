﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmployeeClassLibrary
{
    public class EmployeeClass
    {
        //Field 
        private string _name;
        private int _IDnumber;
        private string _department;
        private string _position;

        // Constructor
        public EmployeeClass()
        {
            _name = "";
            _IDnumber = 0;
            _department = "";
            _position = "";
        }
        //Name property
        public string Name
        {
            get; set;
        }
        //ID Number property
        public int IDnumber
        {
            get; set;
        }
        //department property
        public string Department
        {
            get; set;
        }
        //position property
        public string Position
        {
            get; set;
        }
    }
}
