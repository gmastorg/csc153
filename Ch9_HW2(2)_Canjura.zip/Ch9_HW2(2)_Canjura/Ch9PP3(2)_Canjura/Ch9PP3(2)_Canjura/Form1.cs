﻿/**
* 05/13/2018
* CSC 153
* Gabriela Canjura
* creates an address book that when names are clicked displays address age and phone
* has 3 people pre programmed and can have others added
*/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using PersonalInformationClassLibrary;

namespace Ch9PP3_2__Canjura
{
    public partial class Form1 : Form
    {
        List<PersonalInformation> person = new List<PersonalInformation>();

        //creates 3 objects 
        PersonalInformation me = new PersonalInformation();
        PersonalInformation friend1 = new PersonalInformation();
        PersonalInformation friend2 = new PersonalInformation();

        public Form1()
        {
            InitializeComponent();
        }

        //hardcodes 3 entries into address book
        public void setPeople()
        {
            me.Name = "Gabriela Canjura";
            me.Address = "123 Somewhere St";
            me.Age = 30;
            me.Phone = "(413)-365-5426";

            friend1.Name = "Raphael Astorga";
            friend1.Address = "826 Florida Ave";
            friend1.Age = 23;
            friend1.Phone = "(919)-342-4568";

            friend2.Name = "Marta Messinger";
            friend2.Address = "28 Noel St";
            friend2.Age = 57;
            friend2.Phone = "(602)-975-6325";
        }

        public void GetPersonData(PersonalInformation person)
        {
            //get name
            person.Name = nameTextBox.Text;
            //get address
            person.Address = addressTextBox.Text;
            //get age
            person.Age = int.Parse(ageMaskedTextBox.Text);
            //get phone number
            person.Phone = phoneMaskedTextBox.Text;
        }

        //displays names and sets the three hardcoded objects when form loads
        private void Form1_Load(object sender, EventArgs e)
        {
            setPeople();

            addressBookListBox.Items.Add(me.Name);
            person.Add(me);
            addressBookListBox.Items.Add(friend1.Name);
            person.Add(friend1);
            addressBookListBox.Items.Add(friend2.Name);
            person.Add(friend2);

        }

        // adds new friends to address book
        private void enterButton_Click(object sender, EventArgs e)
        {
            PersonalInformation myFriend = new PersonalInformation();
            GetPersonData(myFriend);
            person.Add(myFriend);

            addressBookListBox.Items.Add(myFriend.Name);

            //clear text boxes
            nameTextBox.Text = "";
            addressTextBox.Text = "";
            ageMaskedTextBox.Text = "";
            phoneMaskedTextBox.Text = "";

            //reset focus
            nameTextBox.Focus();
        }

        private void addressBookListBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            //get the index of the selected item
            int index = addressBookListBox.SelectedIndex;

            // display address, age, and phone
            MessageBox.Show("Address: " + person[index].Address + "\nAge: " + person[index].Age.ToString() +
                "\nPhone: "+ person[index].Phone);
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            //closes form
            this.Close();
        }

       
    }
}
