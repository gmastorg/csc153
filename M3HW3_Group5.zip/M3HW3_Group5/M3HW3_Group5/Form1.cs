﻿/**
* 02/28/2018
* CSC 153
* Group 5 (Gabriela Canjura, David Howland, Robert Land)
* Has user select a workshop and a location then calculates the lodging cost as well as the total cost
*/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace M3HW3_Group5
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void calculateButton_Click(object sender, EventArgs e)
        {
            int workshop; // hold workshop selected
            int location; // holds selected location
            int lodging; // used to calculate lodging
            int total;
            int registration = 0;// holds registration cost
            int days = 0; // holds days of conference

            workshop = workshopListBox.SelectedIndex;

                switch (workshop)
                {
                    case 0:
                        registration = 1000;
                        days = 3;
                        break;
                    case 1:
                        registration = 800;
                        days = 3;
                        break;
                    case 2:
                        registration = 1500;
                        days = 3;
                        break;
                    case 3:
                        registration = 1300;
                        days = 5;
                        break;
                    case 4:
                        registration = 1500;
                        days = 3;
                        break;
                    default:
                        MessageBox.Show("Select a Workshop.");
                        break;

                }
                                   
            location = locationListBox.SelectedIndex;

                switch (location)
                {
                    case 0:
                        lodging = days* 150;
                        total = registration + lodging;
                        registrationLabel.Text = registration.ToString("c");
                        lodgingLabel.Text = lodging.ToString("C");
                        totalLabel.Text = total.ToString("c");
                        break;

                    case 1:
                        lodging = days * 225;
                        total = registration + lodging;
                        registrationLabel.Text = registration.ToString("c");
                        lodgingLabel.Text = lodging.ToString("C");
                        totalLabel.Text = total.ToString("c");
                        break;
                    case 2:
                        lodging = days * 175;
                        total = registration + lodging;
                        registrationLabel.Text = registration.ToString("c");
                        lodgingLabel.Text = lodging.ToString("C");
                        totalLabel.Text = total.ToString("c");
                        break;
                    case 3:
                        lodging = days * 300;
                        total = registration + lodging;
                        registrationLabel.Text = registration.ToString("c");
                        lodgingLabel.Text = lodging.ToString("C");
                        totalLabel.Text = total.ToString("c");
                        break;
                    case 4:
                        lodging = days * 175;
                        total = registration + lodging;
                        registrationLabel.Text = registration.ToString("c");
                        lodgingLabel.Text = lodging.ToString("C");
                        totalLabel.Text = total.ToString("c");
                        break;
                    case 5:
                        lodging = days * 150;
                        total = registration + lodging;
                        registrationLabel.Text = registration.ToString("c");
                        lodgingLabel.Text = lodging.ToString("C");
                        totalLabel.Text = total.ToString("c");
                        break;
                default:
                    MessageBox.Show("Select a Location.");
                    break;
            }     
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
