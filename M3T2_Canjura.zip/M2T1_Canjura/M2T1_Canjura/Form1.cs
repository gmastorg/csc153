﻿/**
* 02/21/2018
* CSC 153
* Gabriela Canjura
* calculates miles per gallon validates input (took tutorial from before and updated with new info)
*/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace M2T1_Canjura
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void calculateButton_Click(object sender, EventArgs e)
        {
            double miles; //hold miles driven
            double gallons; // hold gallons used
            double mpg; // hold MPG

            if (double.TryParse(milesTextBox.Text, out miles))
            {
                if (double.TryParse(gallonsTextBox.Text, out gallons))
                {
                    //Calculate MPG
                    mpg = miles / gallons;

                    //Display MPG
                    mpgLabel.Text = mpg.ToString("n1");
                }

                else
                {
                    //Display error message for gallons text box
                    MessageBox.Show("Invalid input for gallons.");
                }
            }
            else
            {
                //display error message for miles text box
                MessageBox.Show("Invalid input for miles.");
            }

        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
