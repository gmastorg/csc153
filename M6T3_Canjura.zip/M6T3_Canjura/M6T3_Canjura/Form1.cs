﻿/**
* 04/13/2018
* CSC 153
* Gabriela Canjura
* uses methods to collect information from a file and display it in a list box
*/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace M6T3_Canjura
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        // The GetFileName method gets a filename from the
        //user and assigns it to the variable passed as 
        // an argument.
        private void GetFileName(out string selectedFile)
        {
            if (openFileDialog.ShowDialog() == DialogResult.OK)
            {
                selectedFile = openFileDialog.FileName;
            }
            else
            {
                selectedFile = "";
            }
        }
        //The GetCountries method accepts a filename as an
        //argument. It opens the specified file and displays
        // its contents in the countriesListBox control.
        private void GetCountries (string filename)
        {
            try
            {
                //Declare a variable to hold a country name
                string countryName;

                //Declare a StreamReader variable.
                StreamReader inputFile;

                //Open the file and get a StreamReader object.
                inputFile = File.OpenText(filename);

                //Clear anything currently in the ListBox.
                countriesListBox.Items.Clear();

                //Read the file's contents.
                while (!inputFile.EndOfStream)
                {
                    //Get a country name. 
                    countryName = inputFile.ReadLine();

                    //add the country name to the ListBox.
                    countriesListBox.Items.Add(countryName);
                }

                //Close the file.
                inputFile.Close();
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void getCountriesButton_Click(object sender, EventArgs e)
        {
            string filename; // to hold the filename

            //Get  the filenme from the user.
            GetFileName(out filename);

            //Get the countries from the file.
            GetCountries(filename);
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            //Close the form.
            this.Close();
        }
    }
}
